#include "../system.h"

extern uint32_t __start;
extern uint32_t __end;

uint8_t* memmap_address;
uint32_t memory_slots;

uint32_t kernel_location;
uint32_t kernel_size;
uint32_t kernel_end;

uint32_t mem_map_start;
uint32_t mem_map_size;
uint32_t mem_map_end;

//WARNING: whe using Kmalloc, the first 32 bit unsigned integer of every kilobyte is unsuable. DON"T USE IT! usage will fry the manager. This will be fixed soon
// say you call uint32_t* addr = kmalloc(2048);
// addr[0], and addr[1024] are ABSOLUELY NOT ALLOWED TO BE USED. if you do a memcpy or memset, it is okay to DIRECTLY AFTERWARDS change offsets 0 and 1024 back
// to MEM_MNGR_USED_SLOT. also, there is no memory protection yet, because paging doesn't work yet, so if you try to use data not pointed to by the kmalloc pointer, other kernel data could be corrupted.

//TODO align memory blocks on 1kb boundaries. will be useful once paging is enabled

int memory_init(struct multiboot_header* mboot_header)
{
  //1. find size & location of kernel
  //2. modify free slots to exclude memory, multiboot header, and kernel
  
  memory_slots = mboot_header->mmap_length / sizeof(mboot_memmap_t);
  
  kernel_location = (uint32_t)&__start;
  kernel_size = (((uint32_t)&__end) - ((uint32_t)&__start));
  kernel_end = (uint32_t)&__end;
  
  mem_map_start = (uint32_t)mboot_header->mmap_addr;
  mem_map_size  = (uint32_t)mboot_header->mmap_length;
  mem_map_end = (uint32_t)mboot_header->mmap_addr + (uint32_t)mboot_header->mmap_length;
  
  //printf("kernel location %d / %dKB\n", kernel_location, kernel_location/1024);
  //printf(".......size     %d / %dKB\n", kernel_size, kernel_size/1024);
  //printf(".......end      %d / %dKB\n", kernel_end, kernel_end/1024);  
  
  mboot_memmap_t mmap_entries[memory_slots];
  memcpy((char*)&mmap_entries, (char*)mboot_header->mmap_addr, mboot_header->mmap_length);
  
  for (uint32_t i = 0; i < memory_slots; i++)
  {
    if ((uint32_t)mmap_entries[i].type == MULTIBOOT_MMAP_FREE_MEMORY)
    {
      if (kernel_location >= (uint32_t)mmap_entries[i].base_addr && 
          kernel_end <= ((uint32_t)mmap_entries[i].length+(uint32_t)mmap_entries[i].base_addr))
      {
        mmap_entries[i].base_addr += (uint64_t)kernel_size;
        mmap_entries[i].length -= (uint64_t)kernel_size;
          //printf("::::shrunk slot %d %d / %dKB\n", i, (uint32_t)kernel_size, (uint32_t)kernel_size / 1024);
      }
      if (mem_map_start >= (uint32_t)mmap_entries[i].base_addr && 
          mem_map_end <= ((uint32_t)mmap_entries[i].length+(uint32_t)mmap_entries[i].base_addr))
      {
        mmap_entries[i].base_addr += (uint64_t)mem_map_size;
        mmap_entries[i].length -= (uint64_t)mem_map_size;
        //printf("::::shrunk slot %d %d / %dKB\n", i, (uint32_t)mem_map_size, (uint32_t)mem_map_size / 1024);
      }
    }
    //printf("mmap entry     %d\n", i);
    //printf("....entry size %d\n", (uint32_t)mmap_entries[i].size);
    //printf("....addr       %d / %dKB\n", (uint32_t)mmap_entries[i].base_addr, (uint32_t)mmap_entries[i].base_addr/1024);
    //printf("....length     %d / %dKB\n", (uint32_t)mmap_entries[i].length, (uint32_t)mmap_entries[i].length/1024);
    //printf("....end addr   %d / %dKB\n", (uint32_t)mmap_entries[i].base_addr + (uint32_t)mmap_entries[i].length, ((uint32_t)mmap_entries[i].base_addr + (uint32_t)mmap_entries[i].length)/1024);
    //printf("....type       %d\n\n", (uint32_t)mmap_entries[i].type);
  }
  
  //printf("memory map is now valid\n\n");
  
  //okay, now what?
  //we have a table of free and used memory, and we have all the tables marked as used
  //we now need to mark all the free spots as free,
  //   
  
  for (uint32_t i = 0; i < memory_slots; i++)
  {
    if (mmap_entries[i].type == MULTIBOOT_MMAP_FREE_MEMORY)
    {
      for (uint32_t e = (uint32_t)mmap_entries[i].base_addr; e < (uint32_t)mmap_entries[i].base_addr + (uint32_t)mmap_entries[i].length; e += MEM_MNGR_SLOT_SIZE)
      {
        uint32_t* addr = (uint32_t*)e;
        addr[0] = MEM_MNGR_FREE_SLOT;
        //printf("marked slot %d as free\n", e);
      }
    }
  }
  //now we nead to copy back the new memory map table:
  memcpy((char*)mboot_header->mmap_addr, (char*)&mmap_entries, mboot_header->mmap_length);
  
  
  //printf("kmalloc test 1: %d\n", (uint32_t)kmalloc(2048));
  //printf("kfree   test 1: %d\n", (uint32_t)kfree((uint32_t*)1168, 1024));
  //printf("kmalloc test 2: %d\n", (uint32_t)kmalloc(4096));
  
  return K_SUCCESS;
}

uint32_t* kmalloc(uint32_t length)
{
  int failed = 0;
  uint32_t mem_blocks = (length / MEM_MNGR_SLOT_SIZE);  //number of blocks needed to grant requested memory
  if (length % MEM_MNGR_SLOT_SIZE != 0)            // if it isn't a multiple of 1K, add a block to the nedded blocks
    mem_blocks += 1;
  
  mboot_memmap_t mmap_entries[memory_slots];
  
  struct multiboot_header* mboot_header;
  mboot_header = multiboot_get_address();
  memcpy((char*)&mmap_entries, (char*)mboot_header->mmap_addr, mboot_header->mmap_length);
  //find a free block, then see if there are contiguous blocks for the length required
  //if so, mark them all as used, and return the pointer to the first block
  //if not, we need to compact the memory map! we can't do this until we have paging.
  
  for (uint32_t i = 0; i < memory_slots; i++) {
    //printf("in memory slot %d, with base addr of %d\n", i, (uint32_t)mmap_entries[i].base_addr);
    if (mmap_entries[i].type == MULTIBOOT_MMAP_FREE_MEMORY) {
      //printf("..found free memory slot %d\n", i);
      
      for (uint32_t e = (uint32_t)mmap_entries[i].base_addr; e < (uint32_t)mmap_entries[i].base_addr + (uint32_t)mmap_entries[i].length; e += MEM_MNGR_SLOT_SIZE) {
        //printf("....in memory chunk %d\n", e);
        uint32_t* addr = (uint32_t*)e;
        
        if (addr[0] == MEM_MNGR_FREE_SLOT) {
          //printf("......found free chunk %d\n", e);
          for(uint32_t block = 0; block < mem_blocks; block++)
          {
            //printf("......looping through memory chunk %d\n", e+(block*MEM_MNGR_SLOT_SIZE));
            if (addr[block*MEM_MNGR_SLOT_SIZE] != MEM_MNGR_FREE_SLOT)
            {
              //printf("........chunk %d is not free\n", e+(block*MEM_MNGR_SLOT_SIZE));
              goto no_slot_found;
            }
            else
            {
              //printf("........chunk %d is free\n", e+(block*MEM_MNGR_SLOT_SIZE));
            }
          }
          for (uint32_t marking = 0; marking < mem_blocks; marking++)
          {
            uint32_t* marker = (uint32_t*)(e+(marking*MEM_MNGR_SLOT_SIZE));
            marker[0] = MEM_MNGR_USED_SLOT;
          }
          return (uint32_t*)(e);
          no_slot_found:
          failed++;
        }
        else
        {
          //printf("......chunk %d is not free\n", e);
        }
      }
    }
  }
  //printf("sorry, no memory slot was found with a length of %d blocks.\n", mem_blocks);
  
  return (uint32_t*)0;  
  /*
  
  mboot_memmap_t mmap_entries[memory_slots];
  
  struct multiboot_header* mboot_header;
  mboot_header = multiboot_get_address();
  
  memcpy((char*)&mmap_entries, (char*)mboot_header->mmap_addr, mboot_header->mmap_length);
  
  int free_slots_found = 0;
  uint32_t addr_free_blocks[mem_blocks];
  
  for (uint32_t i = 0; i < memory_slots; i++)
  {
    if (mmap_entries[i].type == MULTIBOOT_MMAP_FREE_MEMORY)
    {
      for (uint32_t e = (uint32_t)mmap_entries[i].base_addr; e < (uint32_t)mmap_entries[i].base_addr + (uint32_t)mmap_entries[i].length; e += MEM_MNGR_SLOT_SIZE)
      {
        if ((uint64_t*)(e) == MEM_MNGR_FREE_SLOT)
        {
          free_slots_found++;
          if (free_slots_found > mem_blocks)
          {
            goto slot_search_done;
          }
          addr_free_blocks[free_slots_found-1] = e;
        }
      }
    }
  }
  
  slot_search_done:
  for (int i = 0; i < mem_blocks; i++)
  {
    uint64_t* ptr = (uint64_t*)addr_free_blocks[i];
    ptr[0] = MEM_MNGR_USED_SLOT;
    if (i  == (mem_blocks-1))
    {
      ptr[1] = MEM_MNGR_LAST_BLOCK;
    }
    else
    {
      ptr[1] = (uint64_t)addr_free_blocks[i+1];
    }
  }
  return (uint64_t*)addr_free_blocks[0];*/
}

int kfree(uint32_t* base, uint32_t length)
{
  uint32_t mem_blocks = (length / MEM_MNGR_SLOT_SIZE);  //number of blocks needed to grant requested memory
  if (length % MEM_MNGR_SLOT_SIZE != 0)            // if it isn't a multiple of 1K, add a block to the nedded blocks
    mem_blocks += 1;
    
  for (uint32_t i = 0; i < mem_blocks; i++)
  {
    uint32_t* addr = (uint32_t*)(base + i*MEM_MNGR_SLOT_SIZE);
    addr[0]=MEM_MNGR_FREE_SLOT;
    for (int j = 1; j < MEM_MNGR_SLOT_SIZE-1; j++)
    {
      addr[j] = 0;
    }
    
  }
  return K_SUCCESS;
}